# Arsha.Codes - Open Source UMKM - Supabase Connected ✅

**Live DB:** https://zvsfmiqqtdwyzacfkydy.supabase.co
**WA Business:** 081958089311 (6281958089311)
**QRIS:** a.n Arsha.Codes - NMID ID1026616552455 A01
**Harga:** 350rb / 650rb / 950rb - Sekali bayar

## Status
✅ Supabase tables created - Success. No rows returned.
✅ QRIS real terpasang
✅ WA Business auto konek
✅ Bug NaN fixed - Antri/Potong/Jahit/Selesai & Sehat/Perawatan/Sakit jalan

## Fitur
- Konveksi Management: Antri → Potong → Jahit → Selesai
- Farm Management: Sehat / Perawatan / Sakit
- Order CRUD: Masuk Supabase + auto WA ke 081958089311
- Demo: Kirim rekap ke WA manual (customer bisa test ke WA pribadi)
- No chat customer, no preview WA, no DP text - clean

## Deploy

### 1. GitHub
```bash
git init
git add .
git commit -m "feat: Arsha.Codes Supabase live"
git branch -M main
git remote add origin https://github.com/username/arsha-codes.git
git push -u origin main
```

### 2. Netlify
- Import from GitHub
- Build command: (empty)
- Publish dir: /
- Env: VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY (optional, already hardcoded safe key)

### 3. Supabase
Sudah selesai! Tables sudah ada di zvsfmiqqtdwyzacfkydy.

Cek di Table Editor:
- konveksi_orders
- farm_data
- app_orders

## Struktur
- index.html (main app with Supabase live)
- public/qris-arsha-codes-real.jpg (QRIS asli)
- supabase/schema.sql
- .env.example

MIT License - Untuk UMKM Indonesia
